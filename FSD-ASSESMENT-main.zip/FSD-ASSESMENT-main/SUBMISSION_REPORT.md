# Student Team Members Management Application

## Submission Report

### Assessment Details

- Course: `21CSS301T - Full Stack Development`
- Assessment: `CLAT-2 Online Assessment`
- Task Name: `Student Team Members Management Application`
- Technology Stack: `React.js`, `Node.js`, `Express.js`, `MongoDB`, `Mongoose`, `Axios`, `Multer`, `CSS`

### Team Details

- Team Name: `Team Alpha`
- Repository Name: `Team-Alpha`
- GitHub Repository Link: `Add your public GitHub repository URL here`
- Branch Used: `main`

If your actual team name is different, update the team name and repository name before submission.

## Project Overview

This project is a full-stack web application developed for managing student team members. The application allows users to add new members, upload profile images, view all team members, and see complete individual member details. The frontend is built using React.js with React Router, and the backend is developed using Node.js, Express.js, and MongoDB.

## Implemented Features

### Frontend

- Home page with team name, welcome section, and navigation buttons
- Add Member page with validated form inputs
- Profile image upload support
- View Members page with card layout
- Member Details page with full individual data
- Axios-based API integration
- Loading and error state handling
- Basic consistent CSS styling

### Backend

- REST API using Express.js
- MongoDB integration using Mongoose
- Multer-based image upload support
- Static serving for uploaded images
- Member schema with name, role, email, contact, and image
- CORS enabled
- Environment-variable-based MongoDB connection

## API Endpoints Used

- `POST /api/members` - Add a new member with image upload
- `GET /api/members` - Fetch all members
- `GET /api/members/:id` - Fetch details of a single member
- `GET /api/health` - Health check endpoint

## Folder Structure

```text
fsd assesment/
|-- config/
|   |-- db.js
|-- controllers/
|   |-- memberController.js
|-- frontend/
|   |-- public/
|   |-- src/
|   |   |-- pages/
|   |   |   |-- Home.js
|   |   |   |-- AddMember.js
|   |   |   |-- ViewMembers.js
|   |   |   |-- MemberDetails.js
|   |   |-- api.js
|   |   |-- App.js
|   |   |-- index.js
|   |   |-- styles.css
|   |-- package.json
|-- models/
|   |-- Member.js
|-- routes/
|   |-- memberRoutes.js
|-- uploads/
|-- .gitignore
|-- package.json
|-- README.md
|-- server.js
|-- SUBMISSION_REPORT.md
```

## MongoDB Setup

The backend uses MongoDB Atlas through the `MONGODB_URI` value in the root `.env` file.

Example:

```env
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/student-team-members?retryWrites=true&w=majority
```

## How To Run The Project

### Backend

```bash
npm install
npm run dev
```

### Frontend

```bash
cd frontend
npm install
npm start
```

## Git Details

- Git repository initialized locally before push
- Main branch recommended: `main`
- Public GitHub repository required as per assessment
- `.gitignore` added to exclude `node_modules`, `.env`, and other unnecessary files

## Sample Git Commands Used

```bash
git init
git branch -M main
git add .
git commit -m "Initial submission for Student Team Members Management Application"
git remote add origin https://github.com/<your-username>/<your-team-repo>.git
git push -u origin main
```

## Submission Notes

- The repository should be public
- The repository name should match the team name
- README must be included
- All required frontend and backend files are included
- API routes follow the assessment requirements
- Image uploads are stored in the `uploads` folder

## Conclusion

The application satisfies the required assessment criteria by implementing a complete React frontend, Express backend, MongoDB database integration, API routing, file upload handling, and GitHub-ready project structure.
