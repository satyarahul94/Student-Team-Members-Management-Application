const mongoose = require("mongoose");

const DATABASE_URI = process.env.MONGODB_URI;

const maskConnectionString = (uri) => {
  if (!uri) {
    return "undefined";
  }

  return uri.replace(/\/\/([^:]+):([^@]+)@/, "//$1:****@");
};

const getConnectionMode = (uri) => {
  if (uri.startsWith("mongodb+srv://")) {
    return "mongodb-atlas";
  }

  if (uri.startsWith("mongodb://")) {
    return uri.includes("127.0.0.1") || uri.includes("localhost")
      ? "local-mongodb"
      : "mongodb";
  }

  return "unknown";
};

const validateDatabaseUri = (uri) => {
  if (!uri) {
    throw new Error("MONGODB_URI is missing. Add it to the root .env file.");
  }

  if (!uri.startsWith("mongodb://") && !uri.startsWith("mongodb+srv://")) {
    throw new Error(
      "Invalid MONGODB_URI. It must start with mongodb:// or mongodb+srv://"
    );
  }

  if (uri.includes("<db_password>") || uri.includes("YOUR_REAL_PASSWORD")) {
    throw new Error(
      "MONGODB_URI still contains a placeholder password. Replace it with the real database password."
    );
  }
};

const logConnectionHelp = (error, uri) => {
  if (error.message.includes("ECONNREFUSED")) {
    console.error(
      "[db] MongoDB refused the connection. If you are using local MongoDB, make sure the service is installed and running."
    );
  }

  if (
    uri.startsWith("mongodb+srv://") &&
    (error.message.toLowerCase().includes("bad auth") ||
      error.message.toLowerCase().includes("authentication failed"))
  ) {
    console.error(
      "[db] Atlas authentication failed. Check the username, password, and Atlas IP access list."
    );
  }

  if (error.message.includes("ENOTFOUND")) {
    console.error(
      "[db] MongoDB host could not be resolved. Verify the Atlas cluster URL and your internet connection."
    );
  }
};

const connectToDatabase = async () => {
  validateDatabaseUri(DATABASE_URI);

  const connectionMode = getConnectionMode(DATABASE_URI);

  console.log(`[db] Connecting using ${connectionMode}...`);
  console.log(`[db] Connection target: ${maskConnectionString(DATABASE_URI)}`);

  try {
    await mongoose.connect(DATABASE_URI, {
      serverSelectionTimeoutMS: 10000,
    });

    console.log("[db] MongoDB connected successfully.");
  } catch (error) {
    console.error("[db] MongoDB connection failed:", error.message);
    logConnectionHelp(error, DATABASE_URI);
    throw error;
  }
};

module.exports = {
  connectToDatabase,
};
