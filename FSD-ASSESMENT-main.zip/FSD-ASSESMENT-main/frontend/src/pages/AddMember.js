import { useState } from "react";
import { Link } from "react-router-dom";
import api from "../api";

const initialFormState = {
  name: "",
  role: "",
  email: "",
  contact: "",
};

function AddMember() {
  const [formData, setFormData] = useState(initialFormState);
  const [imageFile, setImageFile] = useState(null);
  const [errors, setErrors] = useState({});
  const [serverMessage, setServerMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateForm = () => {
    const nextErrors = {};

    if (!formData.name.trim()) {
      nextErrors.name = "Name is required";
    }

    if (!formData.role.trim()) {
      nextErrors.role = "Role is required";
    }

    if (!formData.email.trim()) {
      nextErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      nextErrors.email = "Please enter a valid email address";
    }

    if (!formData.contact.trim()) {
      nextErrors.contact = "Contact is required";
    }

    if (!imageFile) {
      nextErrors.image = "Profile image is required";
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((current) => ({
      ...current,
      [name]: value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setServerMessage("");

    if (!validateForm()) {
      return;
    }

    const payload = new FormData();
    payload.append("name", formData.name);
    payload.append("role", formData.role);
    payload.append("email", formData.email);
    payload.append("contact", formData.contact);
    payload.append("image", imageFile);

    try {
      setIsSubmitting(true);
      await api.post("/members", payload, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      setServerMessage("Member added successfully.");
      setFormData(initialFormState);
      setImageFile(null);
      setErrors({});
      event.target.reset();
    } catch (error) {
      setServerMessage(
        error.response?.data?.message || "Unable to add member right now."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="page-shell">
      <section className="content-card">
        <div className="page-header">
          <div>
            <p className="eyebrow">Add Team Member</p>
            <h2>Create a new member profile</h2>
          </div>
          <Link className="button ghost" to="/members">
            View Members
          </Link>
        </div>

        <form className="member-form" onSubmit={handleSubmit}>
          <label>
            Name
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter full name"
            />
            {errors.name ? <span className="field-error">{errors.name}</span> : null}
          </label>

          <label>
            Role
            <input
              type="text"
              name="role"
              value={formData.role}
              onChange={handleChange}
              placeholder="Enter role"
            />
            {errors.role ? <span className="field-error">{errors.role}</span> : null}
          </label>

          <label>
            Email
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter email"
            />
            {errors.email ? <span className="field-error">{errors.email}</span> : null}
          </label>

          <label>
            Contact
            <input
              type="text"
              name="contact"
              value={formData.contact}
              onChange={handleChange}
              placeholder="Enter contact number"
            />
            {errors.contact ? (
              <span className="field-error">{errors.contact}</span>
            ) : null}
          </label>

          <label>
            Profile Image
            <input
              type="file"
              name="image"
              accept="image/*"
              onChange={(event) => setImageFile(event.target.files?.[0] || null)}
            />
            {errors.image ? <span className="field-error">{errors.image}</span> : null}
          </label>

          <div className="action-row">
            <button className="button primary" type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Submitting..." : "Save Member"}
            </button>
            <Link className="button secondary" to="/">
              Back Home
            </Link>
          </div>
        </form>

        {serverMessage ? (
          <div
            className={
              serverMessage.includes("successfully")
                ? "alert success"
                : "alert error"
            }
          >
            {serverMessage}
          </div>
        ) : null}
      </section>
    </div>
  );
}

export default AddMember;
