# GitHub Push Steps

Use these steps to upload the project to GitHub.

## 1. Open terminal in the project root

```powershell
cd "C:\Users\mohit\OneDrive\文档\vs codes\fsd assesment"
```

## 2. Initialize Git

```powershell
git init
git branch -M main
```

## 3. Check `.gitignore`

This project already has a `.gitignore` file that excludes:

- `node_modules`
- `.env`
- uploaded files

## 4. Add project files

```powershell
git add .
```

## 5. Create commit

```powershell
git commit -m "Initial submission for Student Team Members Management Application"
```

## 6. Create a GitHub repository

- Go to GitHub
- Click `New repository`
- Repository name: use your team name, for example `Team-Alpha`
- Set it to `Public`
- Do not add README, `.gitignore`, or license from GitHub because the project already contains them

## 7. Add remote

Replace the URL below with your repository URL:

```powershell
git remote add origin https://github.com/<your-username>/<your-team-repo>.git
```

## 8. Push to GitHub

```powershell
git push -u origin main
```

## 9. Verify submission

After push, confirm that GitHub contains:

- backend files
- frontend files
- `README.md`
- `SUBMISSION_REPORT.md`

## 10. Keep this information for submission

- Public GitHub repository link
- Team name
- Branch name: `main`
- Last push date and time
