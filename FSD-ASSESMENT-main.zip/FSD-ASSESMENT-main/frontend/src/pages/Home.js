import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="page-shell">
      <section className="hero-card">
        <p className="eyebrow">Student Team Members Management Application</p>
        <h1>Team Alpha</h1>
        <p className="lead">
          Welcome to the student team dashboard. Add new members, manage their
          information, and view complete team profiles in one place.
        </p>
        <div className="action-row">
          <Link className="button primary" to="/add">
            Add Member
          </Link>
          <Link className="button secondary" to="/members">
            View Members
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Home;
