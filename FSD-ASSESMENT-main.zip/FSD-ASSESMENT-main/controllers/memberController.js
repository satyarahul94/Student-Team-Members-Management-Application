const Member = require("../models/Member");
const fs = require("fs");
const path = require("path");

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const removeUploadedFile = (file) => {
  if (!file?.filename) {
    return;
  }

  const filePath = path.join(__dirname, "..", "uploads", file.filename);

  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }
};

const validateMemberInput = ({ name, role, email, contact }, file) => {
  if (!name || !role || !email || !contact) {
    return "All fields are required";
  }

  if (!emailPattern.test(email)) {
    return "Please enter a valid email address";
  }

  if (!file) {
    return "Profile image is required";
  }

  return null;
};

const addMember = async (req, res, next) => {
  try {
    const { name, role, email, contact } = req.body;
    const validationMessage = validateMemberInput(
      { name, role, email, contact },
      req.file
    );

    if (validationMessage) {
      removeUploadedFile(req.file);
      return res.status(400).json({ message: validationMessage });
    }

    const member = await Member.create({
      name,
      role,
      email,
      contact,
      image: `/uploads/${req.file.filename}`,
    });

    return res.status(201).json({
      message: "Member added successfully",
      member,
    });
  } catch (error) {
    if (error.code === 11000) {
      removeUploadedFile(req.file);
      return res.status(409).json({ message: "Email already exists" });
    }

    return next(error);
  }
};

const getMembers = async (req, res, next) => {
  try {
    const members = await Member.find().sort({ createdAt: -1 });
    return res.status(200).json(members);
  } catch (error) {
    return next(error);
  }
};

const getMemberById = async (req, res, next) => {
  try {
    const member = await Member.findById(req.params.id);

    if (!member) {
      return res.status(404).json({ message: "Member not found" });
    }

    return res.status(200).json(member);
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({ message: "Invalid member ID" });
    }

    return next(error);
  }
};

module.exports = {
  addMember,
  getMembers,
  getMemberById,
};
