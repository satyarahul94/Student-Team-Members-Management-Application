import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api, { getImageUrl } from "../api";

function ViewMembers() {
  const [members, setMembers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    const fetchMembers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/members");
        setMembers(response.data);
      } catch (error) {
        setErrorMessage(
          error.response?.data?.message || "Failed to fetch members."
        );
      } finally {
        setIsLoading(false);
      }
    };

    fetchMembers();
  }, []);

  return (
    <div className="page-shell">
      <section className="content-card">
        <div className="page-header">
          <div>
            <p className="eyebrow">Team Directory</p>
            <h2>View all team members</h2>
          </div>
          <div className="action-row">
            <Link className="button ghost" to="/">
              Home
            </Link>
            <Link className="button primary" to="/add">
              Add Member
            </Link>
          </div>
        </div>

        {isLoading ? <div className="status-box">Loading members...</div> : null}
        {errorMessage ? <div className="alert error">{errorMessage}</div> : null}

        {!isLoading && !errorMessage ? (
          members.length > 0 ? (
            <div className="card-grid">
              {members.map((member) => (
                <article className="member-card" key={member._id}>
                  <img
                    className="member-image"
                    src={getImageUrl(member.image)}
                    alt={member.name}
                  />
                  <div className="member-card-content">
                    <h3>{member.name}</h3>
                    <p>{member.role}</p>
                    <Link className="button secondary full-width" to={`/members/${member._id}`}>
                      View Details
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="status-box">No members found. Add your first member.</div>
          )
        ) : null}
      </section>
    </div>
  );
}

export default ViewMembers;
