import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api, { getImageUrl } from "../api";

function MemberDetails() {
  const { id } = useParams();
  const [member, setMember] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    const fetchMember = async () => {
      try {
        setIsLoading(true);
        const response = await api.get(`/members/${id}`);
        setMember(response.data);
      } catch (error) {
        setErrorMessage(
          error.response?.data?.message || "Failed to fetch member details."
        );
      } finally {
        setIsLoading(false);
      }
    };

    fetchMember();
  }, [id]);

  return (
    <div className="page-shell">
      <section className="content-card">
        <div className="page-header">
          <div>
            <p className="eyebrow">Member Details</p>
            <h2>Complete profile</h2>
          </div>
          <div className="action-row">
            <Link className="button ghost" to="/members">
              Back to Members
            </Link>
            <Link className="button secondary" to="/">
              Home
            </Link>
          </div>
        </div>

        {isLoading ? <div className="status-box">Loading member details...</div> : null}
        {errorMessage ? <div className="alert error">{errorMessage}</div> : null}

        {!isLoading && member ? (
          <div className="details-layout">
            <img
              className="details-image"
              src={getImageUrl(member.image)}
              alt={member.name}
            />
            <div className="details-panel">
              <div className="details-item">
                <span>Name</span>
                <strong>{member.name}</strong>
              </div>
              <div className="details-item">
                <span>Role</span>
                <strong>{member.role}</strong>
              </div>
              <div className="details-item">
                <span>Email</span>
                <strong>{member.email}</strong>
              </div>
              <div className="details-item">
                <span>Contact</span>
                <strong>{member.contact}</strong>
              </div>
            </div>
          </div>
        ) : null}
      </section>
    </div>
  );
}

export default MemberDetails;
